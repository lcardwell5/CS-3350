// File:        lab10.cpp
// Description: driver file for lab 10
// Author:      Luke Cardwell (lcardwe@bgsu.edu)
// Course:      CS3350
#include <iostream>
#include <vector>
#include <algorithm>

template<typename T, size_t N>
std::vector<T> toVector(const T (&arr)[N]) {
    std::vector<int> newVector;
    
    for (int i = 0; i < N; i++)
    {
        newVector.push_back(arr[i]);
    }
    return newVector;
}

template<typename T, size_t N>
void heapSortVector(T (&arr)[N]) {
    std::vector<int> nVector;
    nVector = toVector(arr);
    
    std::make_heap (nVector.begin(),nVector.end());
    std::sort(nVector.begin(), nVector.end());
    std::copy(nVector.begin(), nVector.end(), arr);
}

template<typename T, size_t N>
void heapSort(T (&arr)[N]) {
    std::make_heap(arr, arr + N);
    std::sort(arr, arr+N);
}

//////////////////////////////
// DO NOT MODIFY BELOW HERE //
//////////////////////////////

int failures = 0;

void testEq(int result, int expected) {
    if (result != expected) {
        std::cout << "test FAILED: expected(" << expected << ") but result(" << result << ")" << std::endl;
        failures++;
    }
}

template<typename T, size_t N>
void testArr(T (&arr)[N]) {
    int arr1[N];
    std::copy(arr, arr + N, arr1);
    heapSortVector(arr1);

    int arr2[N];
    std::copy(arr, arr + N, arr2);
    heapSort(arr2);

    std::sort(arr, arr + N);

    for (uint i = 0; i < N; i++) {
        testEq(arr1[i], arr[i]);
        testEq(arr2[i], arr[i]);
    }
}

int main(int argc, char **argv)
{
    int arr1[1] = { 3 };
    testArr(arr1);

    int arr3[3] = { 2, 1, 3 };
    testArr(arr3);

    int sorted[10] = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
    testArr(sorted);

    int reversed[10] = { 10, 9, 8, 7, 6, 5, 4, 3, 2, 1 };
    testArr(reversed);

    int arr50[50] = { 32, 49, 24, 26, 14, 36, 41, 21, 43, 37, 33, 29, 13, 39, 47, 9, 15, 30, 10, 17, 28, 22, 25, 19, 44, 48, 1, 27, 16, 3, 45, 34, 18, 40, 7, 35, 46, 50, 20, 23, 12, 2, 6, 42, 38, 31, 5, 8, 4, 11 };
    testArr(arr50);

    if (failures == 0)
        std::cout << "ALL TESTS PASSED" << std::endl;
    else
        std::cout << failures << " TESTS FAILED" << std::endl;

    return 0;
}
