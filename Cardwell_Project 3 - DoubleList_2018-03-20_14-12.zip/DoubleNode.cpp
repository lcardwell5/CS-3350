// File:        DoubleNode.cpp
// Description: implementation for the class DoubleNode
// Author:      Robert Dyer (rdyer@bgsu.edu)
// Course:      CS3350
#include "DoubleNode.h"

template<class ItemType>
DoubleNode<ItemType>::DoubleNode(const ItemType& anItem, DoubleNode<ItemType>* prevPtr, DoubleNode<ItemType>* nextPtr) :
                item(anItem), prev(prevPtr), next(nextPtr)
{
}

template<class ItemType>
DoubleNode<ItemType>::~DoubleNode()
{
    this->prev = this->next = nullptr;
}

template<class ItemType>
ItemType DoubleNode<ItemType>::getItem() const
{
   return this->item;
}

template<class ItemType>
DoubleNode<ItemType>* DoubleNode<ItemType>::getPrev() const
{
   return this->prev;
}

template<class ItemType>
DoubleNode<ItemType>* DoubleNode<ItemType>::getNext() const
{
   return this->next;
}

template<class ItemType>
void DoubleNode<ItemType>::setPrev(DoubleNode<ItemType>* prevPtr)
{
    this->prev = prevPtr;
}

template<class ItemType>
void DoubleNode<ItemType>::setNext(DoubleNode<ItemType>* nextPtr)
{
    this->next = nextPtr;
}
