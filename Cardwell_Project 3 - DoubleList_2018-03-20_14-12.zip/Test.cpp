#include <iostream>
#include <stdlib.h>
#include "DoubleList.cpp"

int main()
{
    DoubleList<int> list;
    
    list.insertFront(5);
    list.insertFront(3);
    list.insertBack(4);
    std::cout << list.getEntry(2) << std::endl;
    
    
    return 0;
}