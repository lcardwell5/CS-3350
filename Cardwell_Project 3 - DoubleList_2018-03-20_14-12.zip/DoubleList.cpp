// File:        DoubleList.cpp
// Description: implementation file for the class DoubleList
// Author:      Alex Howey (ahowey@bgsu.edu)
// Author:      Luke Cardwell (lcardwe@bgsu.edu)
// Course:      CS3350

// TODO

#include "DoubleList.h"

//Constructor for the DoubleList
//Initializes the head pointer and tail pointer to nullptr, and itemCount to 0
template<class ItemType>
DoubleList<ItemType>::DoubleList() : headPtr(nullptr), tailPtr(nullptr), itemCount(0)
{
}

//isEmpty checks if the list is empty
//Returns true if empty, false otherwise
template<class ItemType>
bool DoubleList<ItemType>::insertFront(const ItemType& newEntry)
{
    //Creation of a temporary pointer that points to a new node of type DoubleNode
    DoubleNode<ItemType> *tPtr = new DoubleNode<ItemType>(newEntry,nullptr,nullptr);
    //If the list is empty, both the head pointer and tail pointer point to the new node
    if (headPtr == nullptr)                                                                   
    {    
        headPtr = tPtr;
        tailPtr = tPtr;
    }
    //Otherwise, put the new node at the front of the list and set previous and next to their
    //correct positions
    else
    {
        tPtr->setNext(headPtr);     
        headPtr->setPrev(tPtr);
        headPtr = tPtr;
    }
    //Increment itemCount
    itemCount++;
    return true;
}

template<class ItemType>
bool DoubleList<ItemType>::insertBack(const ItemType& newEntry)
{
    //Creation of a temporary pointer that points to a new node of type DoubleNode
    DoubleNode<ItemType> *tPtr = new DoubleNode<ItemType>(newEntry,nullptr,nullptr);
    //If the list is empty, both the head pointer and tail pointer point to the new node
    if (headPtr == nullptr)                                                       
    {    
        headPtr = tPtr;
        tailPtr = tPtr;
    }
    //Otherwise, put the new node at the back of the list and set previous and next to their
    //correct positions
    else
    {
        tPtr->setPrev(tailPtr);
        tailPtr->setNext(tPtr);
        tailPtr = tPtr;
    }
    //Increment itemCount
    itemCount++;
    return true;
}

//isEmpty checks if the list is empty
//Returns true if empty, false otherwise
template<class ItemType>
bool DoubleList<ItemType>::isEmpty() const
{
    return itemCount == 0;
}

//getLength returns the length of the list
template<class ItemType>
int DoubleList<ItemType>::getLength() const
{
    return itemCount;
}

//Remove removes a node at a certain position in the list
//Returns true if the removal was successful and false otherwise
template<class ItemType>
bool DoubleList<ItemType>::remove(int position)
{
    //Creation of a current pointer to hold the current position in the list
    DoubleNode<ItemType> *curPtr = nullptr;
    //Creation of a previous pointer to hold the position previous to the postion of the node
    //that will be removed
    DoubleNode<ItemType> *prevPtr = nullptr;
    //Median value used to determine where to start the traversal of the list
    int median = itemCount / 2;
    
    //Checks to see if removal is possible based on the position parameter
    if (position < 0 || position > itemCount)
    {
        return false;
    }
    
    //If the node to be removed is at the front of the list, current pointer points to the
    //first node in the list, and head pointer points to the next node in the list
    else if (position == 1)
    {
        curPtr = headPtr;
        headPtr = headPtr->getNext();
    }
    //If the node to be removed is at the back of the list, current pointer points to the
    //last node in the list, and tail pointer points to the previous node in the list
    else if (position == itemCount)
    {
        curPtr = tailPtr;
        tailPtr = tailPtr->getPrev();
    }
    //If the node to be removed is in the first half of the list, traverse the list with prevPtr
    //and stop one node before the node to be removed.
    //Current pointer points to the node to be removed, and previous pointer points to the
    //next node after the node to be removed.
    else if (position < median)
    {
        prevPtr = headPtr;
        
        for (int k = 1;k < position;k++)
        {
             prevPtr = prevPtr->getNext();
        }
        
        curPtr = prevPtr->getNext();
        prevPtr->setNext(curPtr->getNext());
    }
    //If the node to be removed is in the latter half of the list, traverse the list with prevPtr
    //and stop one node before the node to be removed.
    //Current pointer points to the node to be removed, and previous pointer points to the
    //previous node after the node to be removed.
    else
    {
        prevPtr = tailPtr;
        
        for(int k = itemCount; k > position; k--)
        {
            prevPtr = prevPtr->getPrev();
        }
        curPtr = prevPtr->getPrev();
        prevPtr->setPrev(curPtr->getPrev());
    }
    
    curPtr->setNext(nullptr);       //Unlinking the node to be removed from the list
    curPtr->setPrev(nullptr);       //Unlinking the node to be removed from the list
    delete curPtr;                  //Deallocation of the current pointer
    curPtr = nullptr;               //Set current pointer to null pointer
    itemCount--;                    //Decrement itemCount
    return true;
}

//Clears the list
//Calls remove in a loop and continually removes a node at position one in the list
template<class ItemType>
void DoubleList<ItemType>::clear()
{
    while (!isEmpty())
    {
        remove(1);
    }
    itemCount = 0;      //Set itemCount to 0
}

//getLength returns the length of the list
template<class ItemType>
ItemType DoubleList<ItemType>::getEntry(int position) const
{
     //Creation of a current pointer to hold the current position in the list
     DoubleNode<ItemType> *curPtr = nullptr;
     //Median value used to determine where to start the traversal of the list
     int median = itemCount / 2;
     
     //If the item is the first item in the list, return the item pointed to by the head pointer.
     if (position == 1)
     {
         return headPtr->getItem();
     }
     //If the item is the last item in the list, return the item pointed to by the tail pointer.
     else if (position == itemCount)
     {
         return tailPtr->getItem();
     }
     //If the item is in the first half of the list...
     else if (position < median)
     {
         curPtr = headPtr;
         for (int k = 1; k < position;k++)      //Traverses the list until reaching the destination
         {
             curPtr = curPtr->getNext();
         }
         return curPtr->getItem();          //Returns the item pointed to by the current pointer.
     }
     //If the item is in the latter half of the list...
     else 
     {
         curPtr = tailPtr;
         for (int k = itemCount; k > position; k--) //Traverses list until reaching the destination
         {
             curPtr = curPtr->getPrev();
         }
         return curPtr->getItem(); //Returns the item pointed to by the current pointer
     }
}














