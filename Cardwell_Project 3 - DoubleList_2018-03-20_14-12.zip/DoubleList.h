// File:        DoubleList.h
// Description: header file for the class DoubleList
// Author:      Alex Howey (ahowey@bgsu.edu)
// Author:      Luke Cardwell (lcardwe@bgsu.edu)
// Course:      CS3350

// TODO

#ifndef DOUBLE_LIST_
#define DOUBLE_LIST_
#include "DoubleListInterface.h"
#include "DoubleNode.cpp"

template<class ItemType>
class DoubleList : public DoubleListInterface<ItemType>
{
    public:
        //DoubleList Constructor
        DoubleList();
        //InsertFront inserts a node at the front of the list
        //Returns true if the insertion is successful
        //@pre None
        //@post Returns true on successful insertion
        bool insertFront(const ItemType& newEntry);
        //InsertBack inserts a node at the back of the list
        //Returns true if the insertion is successful
        //@pre None
        //@post Returns true on successful insertion
        bool insertBack(const ItemType& newEntry);
        //isEmpty checks if the list is empty
        //Returns true if empty, false otherwise
        bool isEmpty() const;
        //getLength returns the length of the list
        int getLength() const;
        //Remove removes a node at a certain position in the list
        //Returns true if the removal was successful and false otherwise
        //@pre 1 <= position <= itemCount
        //@post Returns true if the item was successfully removed
        //      Returns false if the position is invalid
        bool remove(int position);
        //Clears the list
        //@post ItemCount is set to 0 and the list is empty
        void clear();
        //Returns the entry at a certain position in the list
        //@pre 1 <= position <= itemCount
        //@post Returns the entry
        ItemType getEntry(int position) const;
    private:
        //pointer that points to the head of the list
        DoubleNode<ItemType> *headPtr;
        //pointer that points to the tail of the list
        DoubleNode<ItemType> *tailPtr;
        //Number of items in the list
        int itemCount = 0;
};

#endif
