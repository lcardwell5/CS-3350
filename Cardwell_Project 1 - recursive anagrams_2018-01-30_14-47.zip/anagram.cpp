// File:        anagram.cpp
// Description: recursive anagram solver
// Authors:     Alex Howey    (ahowey@bgsu.edu)
 //             Luke Cardwell (lcardwe@bgsu.edu)
// Course:      CS3350
// This program will print out every anagram of a word. It outputs the prefix for each unique combination of the remainder.

#include <string>
#include <iostream>


void anagram(std::string prefix, std::string remainder) 
{
    // Base Case 
    // prints out the prefix and remainder when the remainder size is <= 1
    if (remainder.size() <= 1)
    {
        std:: cout <<  prefix << remainder << std::endl;
    }
    else
{
    // recursive case
    // loops until k is < the remainder size
    for (int k = 0;k < remainder.size(); k++)
    {
        // string variable that holds the orgin in which we will test
        std::string orgin = remainder.substr(k,1);
        //string variable that holds the letter/s to the left of our orgin
        std::string left = remainder.substr(0,k);
        //string variable that holds the letter/s to the right of our orgin 
        std::string right = remainder.substr(k + 1);
        //string varibale that holds the next prefix that will be passed in the recursive call
        std::string nextPrefix = prefix + orgin;
        //string varibale that holds the next remainder that will be passed in the recursive call
        std::string nextRemainder = left + right;
        //recursive call to lower the remainder size
        anagram(nextPrefix, nextRemainder);
    }
}
   

}

//////////////////////////////////////////////////////////////
// DO NOT CHANGE BELOW HERE

// declaring a global empty string for efficiency
const std::string emptyString;

/** A helper function to make the recursive function easier to call. */
void anagram(std::string word) {
    anagram(emptyString, word);
}
