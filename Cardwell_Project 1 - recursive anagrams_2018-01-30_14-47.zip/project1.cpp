// File:        project1.cpp
// Description: driver for Project 1
// Author:      Robert Dyer (rdyer@bgsu.edu)
// Course:      CS3350

#include <string>
#include "anagram.cpp"

int main(int argc, char **argv) {
    // simply call on each argument
    for (int i = 1; i < argc; i++) {
        anagram(std::string(argv[i]));
    }

	return 0;
}
