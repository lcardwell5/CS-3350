// File:        lab3.cpp
// Description: driver file for lab 3
// Author:      Robert Dyer (rdyer@bgsu.edu)
// Course:      CS3350

#include <iostream>
#include <vector>
#include "SetBag.cpp"

using namespace std;

void printBag(std::vector<int> v) {
    cout << "size: " << v.size() << endl;
    cout << "contents: ";
    for (std::vector<int>::const_iterator i = v.begin(); i != v.end(); ++i)
            std::cout << *i << ' ';
    cout << endl;
}

int main() {
    SetBag<int> bag;

    bag.add(5);
    bag.add(7);
    bag.add(5);
    bag.add(9);
    printBag(bag.toVector());

    int arr1[] = {5, 8};
    bag.unioned(arr1, 2);
    printBag(bag.toVector());

    int arr2[] = {5, 3};
    bag.difference(arr2, 3);
    printBag(bag.toVector());

    return 0;
}
