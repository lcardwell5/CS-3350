// File:        SetBag.h
// Description: class file header for a bag with set functions
// Author:      Luke Cardwell (lcardwe@bgsu.edu)
// Course:      CS3350, Fall 2017

#ifndef SET_BAG_H_
#define SET_BAG_H_

#include "LinkedBag.cpp"


template<class ItemType>
class SetBag : public LinkedBag<ItemType>
{
    private:
    
    public:
        void unioned(const ItemType items[], const int len);
        void difference(const ItemType items[], const int len);
};

#endif