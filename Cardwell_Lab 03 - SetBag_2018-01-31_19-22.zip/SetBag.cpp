// File:        SetBag.cpp
// Description: class file implementation for a bag with set functions
// Author:      Luke Cardwell (lcardwe@bgsu.edu)
// Course:      CS3350, Fall 2017

#include "SetBag.h"

template<class ItemType>
void SetBag<ItemType>::unioned(const ItemType items[], const int len)
{
    for(int i = 0; i < len; i++)
    {
        this->add(items[i]);
    }
}

template<class ItemType>
void SetBag<ItemType>::difference(const ItemType items[], const int len)
{
    for(int i = 0; i < len; i++)
    {
        while(this->contains(items[i]))
        {
            this->remove(items[i]);
        }
        
    }
}
