// File:        MyStack.cpp
// Description: implementation file for class MyStack
// Authors:     Luke Cardwell (lcardwe@bgsu.edu)
//              TODO (TODO@bgsu.edu)
// Course:      CS3350

#include "MyStack.h"

// pop the top 'n' items off the stack
// returns true if it was able to, otherwise false
// this function should not throw any exceptions
template<class ItemType>
bool MyStack<ItemType>::popmany(int n) {
    if(n <0)
        return false;
    

    for (int i=0; i < n; i++)
    {
        if (this->isEmpty()) 
            return false;
        this->pop();
    }
    return true;
}

// returns the total number of items on the stack
template<class ItemType>
int MyStack<ItemType>::size() {
    MyStack<ItemType> tStack;
    int count = 0;
    
    while(!this->isEmpty())
    {
        tStack.push(this->peek());
        this->pop();
        count++;
    }
    
    while(!tStack.isEmpty())
    {
        this->push(tStack.peek());
        tStack.pop();
    }
    
    return count;
}
