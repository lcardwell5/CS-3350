// File:        MyStack.h
// Description: header file for class MyStack
// Authors:     Luke Cardwell (lcardwe@bgsu.edu)
//               (TODO@bgsu.edu)
// Course:      CS3350
#ifndef MY_STACK_
#define MY_STACK_

#include "LinkedStack.cpp"


template<class ItemType>
class MyStack : public LinkedStack<ItemType>
{
    private:
    public:
        bool popmany(int n);
        int size();
};


#endif