// File:        expressions.h
// Description: function prototypes for Project 2
// Author:      Robert Dyer (rdyer@bgsu.edu)
// Course:      CS3350
#ifndef EXPRESSIONS_H_
#define EXPRESSIONS_H_

#include <string>
#include <vector>

// This function determines operator precedence rules
int precedence(const std::string s);

// This function converts an infix to a postfix
std::vector<std::string> convert(const std::vector<std::string>& infix);

// This function evaluates a postfix expression and returns the result
int evaluate(const std::vector<std::string>& postfix);

#endif
