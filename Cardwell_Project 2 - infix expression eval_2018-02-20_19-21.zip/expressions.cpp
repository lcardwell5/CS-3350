// File:        expressions.cpp
// Description: function implementations for Project 2
// Authors:     Alex Howey (ahowey@bgsu.edu)
//              Luke Cardwell (lcardwe@bgsu.edu)
// Course:      CS3350
#include <iostream>
#include <string>
#include <vector>
#include <sstream>
#include "LinkedStack.cpp"
#include "expressions.h"

// This function tests if the character is an operand or an operator and returns true or false
bool isOperand (std::string test);

int precedence(const std::string s) {
    
    int plus = 1; // Variable that hold the level of precedence for a plus sign
    int minus = 1; // Variable that hold the level of precedence for a minus sign
    int multiply = 2; // Variable that hold the level of precedence for a multiplication sign
    int divide = 2; // Variable that hold the level of precedence for a division sign
    
    // Returns the precedence value
    if (s == "+")
    {
        return plus;
    }
    if (s == "-")
    {
        return minus;
    }
    if (s == "*")
    {
        return multiply;
    }
    if (s == "/")
    {
        return divide;
    }
}

std::vector<std::string> convert(const std::vector<std::string>& infix)
{
    std::vector <std::string> postfix; // Declaration of a vector variable postfix
    
    LinkedStack <std::string> convertStack; // Declaration of a LinkedStack convertStack
    
    // Cycles through the infix expression to create a postfix expression
    for (int k = 0;k < infix.size();k++)
    {
        // If the character is a left parentheses, it pushes the chracter to convertStack
        if (infix[k] == "(")
        {
	        convertStack.push(infix[k]);
        }
        // If the character is a right parentheses then it inserts the characters from the convert stack and pops characters off of convertStack until the left parentheses is reached. Once a left parentheses is reached then that chracter is popped off convertStack
        else if(infix[k] == ")")
        {
	        while (convertStack.peek() != "(")
	        {
	        	postfix.push_back(convertStack.peek());
		    	convertStack.pop();
	        }
	        convertStack.pop();
        }
        // The isOperand function is called to test whether the character is an operand or not. If it is then the character is pushed to the postfix expression
        else if (isOperand(infix[k]) == true)
        {
	        postfix.push_back(infix[k]);
        }
        // The isOperand function is called to test whether the character is an operand or not
        else if (isOperand(infix[k]) == false)
        {
            // While the convertStack is not empty and the top character on convertStack is not a left parentheses and the precedence of the next character in the string is <= the precedence of the top character on convertStack, the top character from convertStack is pushed to the postfix expression. Then the character is popped of convertStack
        	while (!convertStack.isEmpty() && convertStack.peek() != "(" &&
	    	precedence(infix[k]) <= precedence(convertStack.peek()))
	            {
		            postfix.push_back(convertStack.peek());
		            convertStack.pop();
	            }
	            // If the character is a left parentheses or the incoming character from infix has greater precedence than the top character in convertStack, then the infix character is pushed to convertStack 
	        convertStack.push(infix[k]);
        }
        
    }
    // While there is still something in the convertStack, push to the postfix expression and then pop off the convertStack
    while (!convertStack.isEmpty())
    {
        postfix.push_back(convertStack.peek());
        convertStack.pop();
    }
    
    return postfix;
}


int evaluate(const std::vector<std::string>& postfix)
{
    std::string op1; // String variable that holds operand 1
    std::string op2; // String variable that holds operand 2
    int result = 0; // Int variable that holds the result of the two operands
    std::string sResult; // String variable that holds the result as a string
	std::string finalResult; // String variable that holds the final result as a string
    
    LinkedStack <std::string> evalStack; // Declaration of a LinkedStack variable evalStack
    
    // Cycles through the postfix expression
    for (int k = 0;k < postfix.size();k++)
    {
        // If the character of postion k is an operand, the character is pushed to the evalStack
        if (isOperand(postfix[k]) == true)
        {
            evalStack.push(postfix[k]);
        }
        else 
        {
            op2 = evalStack.peek(); // Sets op2 to the value on the top of evalStack
            evalStack.pop(); // Pops the value off of the evalStack
            
            op1 = evalStack.peek(); // Sets op1 to the value on the top of evalStack
            evalStack.pop(); // Pops the value off of the evalStack
            
            // If else statements that evaluates the two operands depending on the operator
            if (postfix[k] == "+")
            {
                result = stoi(op1) + stoi(op2); // stoi converts the string to an integer
            }
            else if (postfix[k] == "-")
            {
                result = stoi(op1) - stoi(op2);
            }
            else if (postfix[k] == "/")
            {
                result = stoi(op1) / stoi(op2);
            }
            else if (postfix[k] == "*")
            {
                result = stoi(op1) * stoi(op2);
            }
            
            sResult = std::to_string(result); // result is converted to a string
            evalStack.push(sResult); // The string result is pushed to the evalStack
            
        }
    
    }
    finalResult = evalStack.peek(); // The finalResult is = to the top of the evalStack
    return stoi(finalResult); // returns finalResult as an integer
}

// This function tests if the character is an operand or an operator and returns true or false
bool isOperand (std::string test)
{
    if (test == "+" || test == "-" || test == "/" || test == "*")
    {
        return false;
    }
    else
    {
        return true;
    }
}








