// File:        project2.cpp
// Description: driver for Project 2
// Author:      Robert Dyer (rdyer@bgsu.edu)
// Course:      CS3350
#include <iostream>
#include <string>
#include <vector>
#include <sstream>
#include <string.h>
#include <iterator>
#include "expressions.h"

int main(int argc, char **argv) {
	bool convertOnly = false;
	bool evalOnly = false;
	int infixPos = 1;

	// check and set arguments
	if (argc < 2) {
		std::cerr << "usage: " << argv[0] << " [-convert|-eval] <infix expression>" << std::endl;
		return -1;
	}

	if (strcmp(argv[1], "-convert") == 0) {
		infixPos++;
		convertOnly = true;
	}

	if (strcmp(argv[1], "-eval") == 0) {
		infixPos++;
		evalOnly = true;
	}

	// read and split the input
	std::istringstream iss(argv[infixPos]);
	std::vector<std::string> input {std::istream_iterator<std::string>{iss}, std::istream_iterator<std::string>{}};

	// convert to postfix, if asked for
	if (!evalOnly) {
		input = convert(input);
	}

	// print the converted expression
	for (int i = 0; i < input.size(); i++) {
		if (i > 0) std::cout << " ";
		std::cout << input[i];
	}

	// print the final result, if asked for
	if (!convertOnly) {
		std::cout << " = " << evaluate(input);
	}

	std::cout << std::endl;

	return 0;
}
