// File:        MyList.cpp
// Description: implementation file for class MyList
// Author:      Luke Cardwell (lcardwe@bgsu.edu)
// Course:      CS3350

#include "MyList.h"

template<class ItemType>
bool MyList<ItemType>::insertFront(const ItemType& item)
{
    return this->insert(1, item);
}

template<class ItemType>
bool MyList<ItemType>::insertEnd(const ItemType& item)
{
    return this->insert(this->getLength() + 1, item);
}

template<class ItemType>
void MyList<ItemType>::removeAll(const ItemType& item)
{
    int k = 0;
    for(k = this->getLength(); k > 0; k--)
    {
        if(this->getEntry(k) == item)
            this->remove(k);
    }
}
