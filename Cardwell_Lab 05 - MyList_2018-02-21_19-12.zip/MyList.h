// File:        MyList.h
// Description: header file for class MyList
// Author:      Luke Cardwell (lcardwe@bgsu.edu)
// Course:      CS3350

#ifndef MYLIST_
#define MYLIST_

#include "LinkedList.cpp"

template <class ItemType>
class MyList : public LinkedList<ItemType>
{
    private:
    public:
        bool insertFront(const ItemType& item);
        bool insertEnd(const ItemType& item);
        void removeAll(const ItemType& item);
};

#endif
