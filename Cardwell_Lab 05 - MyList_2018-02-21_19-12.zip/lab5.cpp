// File:        lab5.cpp
// Description: driver file for lab 5
// Author:      Robert Dyer (rdyer@bgsu.edu)
// Course:      CS3350
#include <iostream>
#include "MyList.cpp"

int main() {
    MyList<int> l;

    l.insert(1, 8);
    l.insert(1, 7);
    l.insert(1, 6);
    l.insert(1, 6);
    l.insert(1, 5);

    l.insertFront(4);
    l.insertEnd(9);

    for (int i = 1; i <= l.getLength(); i++)
        std::cout << l.getEntry(i) << " ";
    std::cout << std::endl;

    l.insertFront(6);
    l.insertEnd(6);
    l.removeAll(6);

    for (int i = 1; i <= l.getLength(); i++)
        std::cout << l.getEntry(i) << " ";
    std::cout << std::endl;

    return 0;
}
