// File:        GreedyBag.h
// Description: header file for the class GreedyBag
// Author:      Luke Cardwell (lcardwe@bgsu.edu)
// Course:      CS3350
#ifndef GREEDY_BAG_H_
#define GREEDY_BAG_H_

// TODO
#include "ArrayBag.cpp"

template <class ItemType>
class GreedyBag : public ArrayBag<ItemType>     //GreedyBag class inherits 
{
public:
	GreedyBag();                                //Default constructor
	void clear();                               //Overridden clear function that
	                                            //doesn't clear items from the
	                                            //bag
	bool remove(const ItemType& anEntry);       //Overridden remove function to
	                                            //return true if the bag has
	                                            //the item and false if the
	                                            //bag doesn't contain the item
private:
	static const int DEFAULT_CAPACITY = 6; // Small size to test for a full bag
   ItemType items[DEFAULT_CAPACITY];      // Array of bag items
   int itemCount;                         // Current count of bag items 
   int maxItems;                          // Max capacity of the bag
   
   // Returns either the index of the element in the array items that
   // contains the given target or -1, if the array does not contain 
   // the target.
   int getIndexOf(const ItemType& target) const;
};

#endif
