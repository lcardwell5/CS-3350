// File:        GreedyBag.cpp
// Description: implementation file for the class GreedyBag
// Author:      Luke Cardwell (lcardwe@bgsu.edu)
// Course:      CS3350

#include "GreedyBag.h"
#include <cstddef>

//This default constructor calls the ArrayBag constructor, and is used when objects of the class are instantiated
template<class ItemType>
GreedyBag<ItemType>::GreedyBag(): itemCount(0), maxItems(DEFAULT_CAPACITY)
{
	ArrayBag<ItemType>();
}

//The clear function does not clear the bag
template<class ItemType>
void GreedyBag<ItemType>::clear()
{
    
}


//The remove function determines if the bag contains an item, and returns true if the bag contains the items and false if it does not
template<class ItemType>
bool GreedyBag<ItemType>::remove(const ItemType& anEntry)
{
    //The ArrayBag contains function is called to determine if that item is contained in the bag. That function returns a boolean value, which is contained in the containItem boolean variable
    bool containItem = ArrayBag<ItemType>::contains(anEntry); 
    return containItem;
}
