// File:        lab1.cpp
// Description: driver file for Lab 1
// Author:      Luke Cardwell (lcardwe@bgsu.edu)
// Course:      CS3350

// TODO
#include <iostream>
#include "GreedyBag.cpp"

int main(int argc, char **argv)
{
	GreedyBag<int> gBag;    //Object instantiation of type int

    //The for loop adds an item to the bag until the index is not less than the argument count
	for (int i = 1; i < argc; i++) 
	{
	    //atoi function used to convert the arguments to an integer, which is then added to the bag
		gBag.add(atoi(argv[i])); 
	}

    //Output the number of items in the bag
	std::cout << gBag.getCurrentSize() << std::endl;

    //Remove function to determine if the item is in the bag
	gBag.remove(atoi(argv[1]));

    //Output the number of items in the bag
	std::cout << gBag.getCurrentSize() << std::endl;

	return 0;
}
