// File:        lab7.cpp
// Description: driver file for lab 7
// Author:      TODO (TODO@bgsu.edu)
// Course:      CS3350
#include <iostream>
#include "PrecondViolatedExcep.cpp"
#include "Node.cpp"
#include "LinkedStack.cpp"
#include "LinkedQueue.cpp"

bool isPalindrome(std::string str) {
    bool isEqual = true;
    
    LinkedStack<char> nStack;
    LinkedQueue<char> nQueue;
    
    for (int i = 0; i < str.size(); i++)
    {
        nStack.push(str[i]);
        nQueue.enqueue(str[i]);
    }
    
    while(isEqual && !nStack.isEmpty())
    {
        if(nStack.peek() == nQueue.peekFront())
        {
            nStack.pop();
            nQueue.dequeue();
        }
        else
        {
            isEqual = false;
        }
    }
    
    return isEqual;
}

////////////////////////////////////
// DO NOT CHANGE BELOW THIS POINT //
////////////////////////////////////

int failures = 0;

void testEq(int result, int expected) {
    if (result != expected) {
        std::cout << "test FAILED: expected(" << expected << ") but result(" << result << ")" << std::endl;
        failures++;
    }
}

int main() {
    testEq(isPalindrome("a"), true);
    testEq(isPalindrome("aa"), true);
    testEq(isPalindrome("aba"), true);
    testEq(isPalindrome("abba"), true);
    testEq(isPalindrome("aab"), false);
    testEq(isPalindrome("aaba"), false);
    testEq(isPalindrome("bbaa"), false);

    if (failures == 0)
        std::cout << "ALL TESTS PASSED" << std::endl;
    else
        std::cout << failures << " TESTS FAILED" << std::endl;

    return 0;
}
