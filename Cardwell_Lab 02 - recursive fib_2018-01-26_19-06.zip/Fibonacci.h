// File:        Fibonacci.h
// Description: class file header for computing Fibonacci numbers
// Author:      Robert Dyer (rdyer@bgsu.edu)
// Course:      CS3350

#ifndef FIBONACCI_H_
#define FIBONACCI_H_

template<class Num>
class Fibonacci {
private:
	/** A helper function for tail recursion. */
	Num tail_helper(Num a, Num b, int n) {
		if (n > 0)
			return this->tail_helper(b, a + b, n - 1);
		return a;
	}

public:
	/** Computes fibonacci numbers recursively. */
	virtual Num recursive(int n) = 0;

	/** Computes fibonacci numbers iteratively. */
	virtual Num iterative(int n);

	/** Computes fibonacci numbers recursively, using tail recursion. */
	virtual Num tail_recursive(int n);
};

#endif 
