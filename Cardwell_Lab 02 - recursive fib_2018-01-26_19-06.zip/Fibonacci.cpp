// File:        Fibonacci.cpp
// Description: class file implementation for computing Fibonacci numbers
// Author:      Robert Dyer (rdyer@bgsu.edu)
// Course:      CS3350

#include "Fibonacci.h"

template<class Num>
Num Fibonacci<Num>::iterative(int n) {
	if (n == 0) return 0;
	if (n == 1) return 1;
	Num prev = 1;
	Num prevprev = 0;
	Num temp = 0;
	for (int i = 2; i <= n; i++) {
		temp = prev + prevprev;
		prevprev = prev;
		prev = temp;
	}
	return temp;
}

template<class Num>
Num Fibonacci<Num>::tail_recursive(int n) {
	return this->tail_helper(0, 1, n);
}
