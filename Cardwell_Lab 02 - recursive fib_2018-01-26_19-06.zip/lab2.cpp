// File:        lab2.cpp
// Description: driver file for lab 2
// Author:      Robert Dyer (rdyer@bgsu.edu)
// Course:      CS3350

#include <iostream>
#include "string.h"
#include "MyFib.cpp"

using namespace std;

int err(char *arg) {
    cerr << "usage: " << arg << " n [-123]" << endl;
    return 1;
}

int main(int argc, char **argv) {
	MyFib<long long> fib;
    bool has1 = false;
    bool has2 = false;
    bool has3 = false;

	if (argc == 1)
        return err(argv[0]);

    if (argc == 2)
        has1 = has2 = has3 = true;

    for (int i = 2; i < argc; i++) {
        if (strcmp(argv[i], "-1") == 0)
            has1 = true;
        else if (strcmp(argv[i], "-2") == 0)
            has2 = true;
        else if (strcmp(argv[i], "-3") == 0)
            has3 = true;
        else {
            cerr << "invalid argument '" << argv[i] << "'" << endl;
            return err(argv[0]);
        }
	}

	long num = atol(argv[1]);

    if (has1) cout << "iterative: "      << fib.iterative(num)      << endl;
    if (has2) cout << "tail recursive: " << fib.tail_recursive(num) << endl;
    if (has3) cout << "recursive: "      << fib.recursive(num)      << endl;

	return 0;
}
