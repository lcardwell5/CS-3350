// File:        MyFib.cpp
// Description: class file implementation for computing Fibonacci numbers
// Author:      lcardwe (lcardwe@bgsu.edu)
// Course:      CS3350

#include "MyFib.h"

template <class Num>
Num MyFib<Num>::recursive(int n) {
    if (n == 0)
        return 0;
    if (n <= 2)
        return 1;
    else
        return recursive(n-1) + recursive(n-2);
}