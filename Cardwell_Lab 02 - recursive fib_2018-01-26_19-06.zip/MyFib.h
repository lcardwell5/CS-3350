// File:        MyFib.h
// Description: class file header for computing Fibonacci numbers
// Author:      lcardwe (lcardwe@bgsu.edu)
// Course:      CS3350

#ifndef MYFIB_H_
#define MYFIB_H_

#include "Fibonacci.cpp"

template<class Num>
class MyFib : public Fibonacci <Num> {
  private:
  
  public:
    Num recursive(int n);
};

#endif