#include <iostream>
#include <algorithm>
#include "PriorityQueueHasAStackedQueue.cpp"

int main()
{
 /*   QueueInterface<int>* theQueue = new QueueAsAStack<int>();
    
	theQueue->enqueue(1);
	theQueue->enqueue(2);
	theQueue->enqueue(3);
	theQueue->enqueue(4);
	
	theQueue->dequeue();
	theQueue->dequeue();
	theQueue->dequeue();
	//theQueue->dequeue();
	
	if (!theQueue->isEmpty())
	    std::cout << "YO" << std::endl;
    
    std::cout << theQueue->peekFront() << std::endl;*/
    
    
    PriorityQueueInterface<int>* pQueue = new PriorityQueueHasAStackedQueue<int>();
    
    bool emptyVal;
    
    pQueue->enqueue(8);
    pQueue->enqueue(5);
    pQueue->enqueue(9);
    pQueue->enqueue(7);
    
     pQueue->dequeue();
     pQueue->dequeue();
    
    emptyVal = pQueue->isEmpty();
    
    std::cout << pQueue->peek() << std::endl;
    
    if (emptyVal == true)
        std::cout << "True" << std::endl;
    else
        std::cout << "False" << std::endl;
    
    return 0; 
}