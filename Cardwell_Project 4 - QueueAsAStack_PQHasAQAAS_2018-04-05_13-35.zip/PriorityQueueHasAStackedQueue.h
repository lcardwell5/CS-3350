// File:        PriorityQueueHasAStackedQueue.h
// Description: header file for PriorityQueueHasAStackedQueue class
// Author:      Luke Cardwell (lcardwe@bgsu.edu)
// Author:      Alex Howey (ahowey@bgsu.edu)
// Course:      CS3350

#ifndef PRIORITY_QUEUE_HAS_A_STACKED_QUEUE_
#define PRIORITY_QUEUE_HAS_A_STACKED_QUEUE_

#include "PriorityQueueInterface.h"
#include "QueueAsAStack.cpp"

template <class ItemType>
class PriorityQueueHasAStackedQueue : public PriorityQueueInterface<ItemType>
{
    private:
    //pointer that points to an instance of QueueAsAStack
    QueueAsAStack<ItemType>* queuePtr;
    
    public:
    //PriorityQueueHasAStackedQueue constructor
    PriorityQueueHasAStackedQueue();
    
    //Determines if the Priority Queue is empty and returns true if empty or //false otherwise
    bool isEmpty() const;
   
    //Adds the new entry in the priority queue based on its priority, returns true
    //@post  New entry is now in the priority queue
    bool enqueue(const ItemType& newEntry);
   
    //Removes the entry from the front of the priority queue, which has the highest priority. Returns true if the items was removed, false otherwise
    //@post Item with the highest priority was removed.
    bool dequeue();
   
    //Returns the item at the front of the priority queue, which has the highest priority.
    //@pre  The priority queue is not empty.
    //@post Item with the highest priority was returned.
    ItemType peek() const;
   
    //PriorityQueueHasAStackedQueue destructor
    ~PriorityQueueHasAStackedQueue();
};


#endif