// File:        PriorityQueueHasAStackedQueue.cpp
// Description: implementation for PriorityQueueHasAStackedQueue class
// Author:      Luke Cardwell (lcardwe@bgsu.edu)
// Author:      Alex Howey (ahowey@bgsu.edu)
// Course:      CS3350
#include "PriorityQueueHasAStackedQueue.h"

//Constructor: Sets the private data member queuePtr to the address of an instance of QueueAsAStack
template <class ItemType>
PriorityQueueHasAStackedQueue<ItemType>::PriorityQueueHasAStackedQueue()
{
    queuePtr = new QueueAsAStack<ItemType>();
}

//Determines if the Priority Queue is empty and returns true if empty or false //otherwise
template <class ItemType>
bool PriorityQueueHasAStackedQueue<ItemType>::isEmpty() const
{
    return queuePtr->isEmpty(); //Calls the QueueAsAStack isEmpty function
}

//Adds the new entry in the priority queue based on its priority, returns true
template <class ItemType>
bool PriorityQueueHasAStackedQueue<ItemType>::enqueue(const ItemType& newEntry)
{
    //temporary queue
    QueueAsAStack<ItemType> tQueue;
    //boolean variable that determines if the new entry is at any point greater than an item at the front of the priority queue
    bool greaterThan = false;
    
    //The new entry is immediately added to the priority queue if the queue is empty
    if(queuePtr->isEmpty())
        queuePtr->enqueue(newEntry);
    //Otherwise...
    else
    {
        //While the priority queue is not empty...
        while(!queuePtr->isEmpty())
        {
            // If the new entry is greater than the item currently at the front of the priority queue...
            if(newEntry > queuePtr->peekFront())
            {
                greaterThan = true;
                //Add new entry to the temporary queue
                tQueue.enqueue(newEntry);
                //Adds the rest of the items in the priority queue to the temporary queue while the priority queue is not empty.
                while(!queuePtr->isEmpty())
                {
                    tQueue.enqueue(queuePtr->peekFront());
                    //Removes the item from the priority queue
                    queuePtr->dequeue();
                }
            }
            //Otherwise...
            else
            {
                //Adds the item at the front of the priority queue to the temporary queue
                tQueue.enqueue(queuePtr->peekFront());
                //Removes the item from the priority queue
                queuePtr->dequeue();
            }
        }
        //If new entry is never greater than any entry in the priority queue...
        if (!greaterThan)
        {
            //Add the new entry to the back of the temporary queue
            tQueue.enqueue(newEntry);
        }
        //Adds all items in the temporary queue back to the priority queue in their proper order
        while(!tQueue.isEmpty())
        {
            queuePtr->enqueue(tQueue.peekFront());
            //Removes the item from the temporary queue
            tQueue.dequeue();
        }
    }
    
    return true;
}

//Removes the entry from the front of the priority queue, which has the highest priority. Returns true if the items was removed, false otherwise
template <class ItemType>
bool PriorityQueueHasAStackedQueue<ItemType>::dequeue()
{
    //Returns false if the priority queue is empty
    if (queuePtr->isEmpty())
        return false;
    //Removes the item from the priority queue
    else
    {
        queuePtr->dequeue();
        return true;
    }    
}

//Returns the item at the front of the priority queue, which has the highest priority.
template <class ItemType>
ItemType PriorityQueueHasAStackedQueue<ItemType>::peek() const
{
    return queuePtr->peekFront();
}

//Dequeues every item in the priority queue
template <class ItemType>
PriorityQueueHasAStackedQueue<ItemType>::~PriorityQueueHasAStackedQueue()
{
    while(!queuePtr->isEmpty())
    {
        queuePtr->dequeue();
    }
}