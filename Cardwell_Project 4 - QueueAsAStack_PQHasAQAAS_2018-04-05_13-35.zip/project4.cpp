// File:        project4.cpp
// Description: driver for Project 4
// Author:      Robert Dyer (rdyer@bgsu.edu)
// Course:      CS3350
#include <iostream>
#include <algorithm>
#include "PriorityQueueHasAStackedQueue.cpp"

int failures = 0;

void testResult(int result, int expected) {
    if (result != expected) {
        std::cout << "test FAILED: expected(" << expected << ") but result(" << result << ")" << std::endl;
        failures++;
    }
}

void testQueue(int* arr, int n) {
	QueueInterface<int>* theQueue = new QueueAsAStack<int>();

	for (int i = 0; i < n; i++)
		theQueue->enqueue(arr[i]);

	for (int i = 0; i < n; i++) {
		if (theQueue->isEmpty()) {
	        std::cout << "test FAILED: queue unexpectedly empty" << std::endl;
	        failures++;
			break;
		}
		testResult(theQueue->peekFront(), arr[i]);
		theQueue->dequeue();
	}

	delete theQueue;
}

void testPriorityQueue(int* arr, int n) {
	PriorityQueueInterface<int>* pQueue = new PriorityQueueHasAStackedQueue<int>();
	int sorted[n];

	for (int i = 0; i < n; i++) {
		sorted[i] = arr[i];
		pQueue->enqueue(arr[i]);
	}

	std::sort(sorted, sorted + n);
	std::reverse(sorted, sorted + n);

	for (int i = 0; i < n; i++) {
		if (pQueue->isEmpty()) {
	        std::cout << "test FAILED: queue unexpectedly empty" << std::endl;
	        failures++;
			break;
		}
		testResult(pQueue->peek(), sorted[i]);
		pQueue->dequeue();
	}

	delete pQueue;
}

int main(int argc, char **argv) {
	int arr1[1] = { 5 };
	int arr2[2] = { 3, 3 };
	int arr6[6] = { 5, 8, 9, 5, 1, 0 };

	testQueue(arr1, 1);
	testPriorityQueue(arr1, 1);

	testQueue(arr2, 2);
	testPriorityQueue(arr2, 2);

	testQueue(arr6, 6);
	testPriorityQueue(arr6, 6);

    if (failures == 0)
        std::cout << "ALL TESTS PASSED" << std::endl;
    else
        std::cout << failures << " TESTS FAILED" << std::endl;

	return 0;
}
