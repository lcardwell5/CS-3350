// File:        QueueAsAStack.h
// Description: header for QueueAsAStack class
// Author:      Luke Cardwell (lcardwe@bgsu.edu)
// Author:      Alex Howey (ahowey@bgsu.edu)
// Course:      CS3350

#ifndef QUEUE_AS_A_STACK_
#define QUEUE_AS_A_STACK_

#include "QueueInterface.h"
#include "LinkedStack.cpp"

template<class ItemType>
class QueueAsAStack : public QueueInterface<ItemType>,
                      private LinkedStack<ItemType>
{
public:
    //Queue Constructor
    QueueAsAStack();
   //Determines if the queue is empty and returns true if empty, or false if not
   bool isEmpty() const;
   
    //Adds a new entry to the back of the QueueAsAStack and returns true if //successful
    //@post NewEntry is now at the back of the QueueAsAStack.
   bool enqueue(const ItemType& newEntry);
   
    //Removes the item at the front of the queue. Returns true if the item was // removed, and false otherwise.
    //@post Removes the front of the QueueAsAStack
   bool dequeue();
   
   
    //@pre The queue is not empty.
    //@post Returns the item at the front of the QueueAsAStack
   ItemType peekFront() const;
   
   //Queue Destructor
   ~QueueAsAStack();
}; // end QueueInterface
#endif
