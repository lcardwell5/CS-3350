// File:        QueueAsAStack.cpp
// Description: implementation for QueueAsAStack class
// Author:      Luke Cardwell (lcardwe@bgsu.edu)
// Author:      Alex Howey (ahowey@bgsu.edu)
// Course:      CS3350

#include "QueueAsAStack.h"

// Constructor: Calls the linked stack constructor
template<class ItemType>
QueueAsAStack<ItemType>::QueueAsAStack()
{
    LinkedStack<ItemType>();
}

//Determines if the QueueAsAStack is empty and returns true if empty, or false //if not
template<class ItemType>
bool QueueAsAStack<ItemType>::isEmpty() const
{
    return LinkedStack<ItemType>::isEmpty();
}

//Adds a new entry to the back of the QueueAsAStack and returns true if successful
template<class ItemType>
bool QueueAsAStack<ItemType>::enqueue(const ItemType& newEntry)
{
    //Creates a temporary stack
    LinkedStack<ItemType> tStack;
    
    //while the linked stack is not empty...
    while(!LinkedStack<ItemType>::isEmpty())
    {
        //push the item at the top of the linked stack to the temporary stack
        tStack.push(LinkedStack<ItemType>::peek()); 
        //pops the item from the linked stack
        LinkedStack<ItemType>::pop();
    }
    
    //Once the linked stack is empty, the new entry is pushed to the tStack
    tStack.push(newEntry);
    
    //While loop to reverse the order of the stack to resemble a queue
    while(!tStack.isEmpty())
    {
        //Push the item at the top of the tStack to the QueueAsAStack
        LinkedStack<ItemType>::push(tStack.peek());
        //pops the item from the tStack
        tStack.pop();
    }
    
    return true;
}

//Removes the item at the front of the queue. Returns true if the item was //removed, and false otherwise.
template<class ItemType>
bool QueueAsAStack<ItemType>::dequeue()
{
    //Returns false if the queueAsAStack is empty (can't remove from an empty //queue)
    if(LinkedStack<ItemType>::isEmpty())
        return false;
    
    //Removes the item from the queueAsAStack    
    LinkedStack<ItemType>::pop();
    
    return true;
}

//Returns the item at the front of the QueueAsAStack
template<class ItemType>
ItemType QueueAsAStack<ItemType>::peekFront() const
{
    return LinkedStack<ItemType>::peek();
}

// Destructor: Calls the linked stack destructor
template<class ItemType>
QueueAsAStack<ItemType>::~QueueAsAStack()
{
    LinkedStack<ItemType>::~LinkedStack();
}