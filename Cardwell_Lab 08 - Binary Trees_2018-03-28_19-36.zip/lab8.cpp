// File:        lab8.cpp
// Description: driver file for lab 8
// Author:      Luke Cardwell (lcardwe@bgsu.edu)
// Course:      CS3350
#include <stdlib.h>
#include <limits.h>
#include <iostream>
#include <stack>
#include "BinaryNodeTree.cpp"

int min = 100;
int max = 0;
int sum = 0;

// gives a random number between 1 and 100
int myrand();

void getMin(int& temp)
{
    if (temp < min)
    {
        min = temp;
    }
}

void getMax(int& temp)
{
    if (temp > max)
    {
        max = temp;
    }
}

void getAvg(int& temp)
{
    sum += temp;
}

BinaryNodeTree<int> createRandomTree() {
    // TODO create a binary tree
    BinaryNodeTree<int> newTree;
    // TODO populate tree with 10 random numbers
    for (int i=0; i < 10; i++)
        newTree.add(myrand());
        
    return newTree;
}

int findTreeMin(const BinaryNodeTree<int>& tree) {
    // TODO compute the minimum value of the tree and return it
    min = 100;
    tree.postorderTraverse(getMin);
    
    return min;
}

int findTreeMax(const BinaryNodeTree<int>& tree) {
    // TODO compute the maximum value of the tree and return it
    max = 0;
    tree.postorderTraverse(getMax);
    
    return max;
}

float findTreeAverage(const BinaryNodeTree<int>& tree) {
    // TODO compute the average value of the tree (as float) and return it
    sum = 0;
    tree.postorderTraverse(getAvg);
    
    double avg = sum / tree.getNumberOfNodes();
    
    return avg;
}




//////////////////////////////
// DO NOT MODIFY BELOW HERE //
//////////////////////////////

std::stack<int> testCheckStack;

int failures = 0;

void checkItem(int& anItem)
{
    if (testCheckStack.empty() || anItem != testCheckStack.top()) {
        if (!testCheckStack.empty())
            std::cout << "test FAILED: expected(" << testCheckStack.top() << ") but result(" << anItem << ")" << std::endl;
        else
            std::cout << "test FAILED: nothing expected but result(" << anItem << ")" << std::endl;
        failures++;
    }
    if (!testCheckStack.empty())
        testCheckStack.pop();
}

void testEq(int result, int expected) {
    if (result != expected) {
        std::cout << "test FAILED: expected(" << expected << ") but result(" << result << ")" << std::endl;
        failures++;
    }
}

int myrand() {
    return 1 + (rand() % 100);
}

int main(int argc, char **argv)
{
    if (argc == 1) {
        srand(50);

        BinaryNodeTree<int> randtree = createRandomTree();

        testCheckStack.push(94);
        testCheckStack.push(90);
        testCheckStack.push(84);
        testCheckStack.push(39);
        testCheckStack.push(83);
        testCheckStack.push(84);
        testCheckStack.push(52);
        testCheckStack.push(46);
        testCheckStack.push(11);
        testCheckStack.push(3);
        randtree.preorderTraverse(checkItem);

        testEq((int)findTreeAverage(randtree), 58);
        testEq(findTreeMin(randtree), 3);
        testEq(findTreeMax(randtree), 94);
    } else {
        if (argv[1][0] == '1') {
            srand(atoi(argv[2])); 
            BinaryNodeTree<int> randtree = createRandomTree();

            testCheckStack.push(73);
            testCheckStack.push(83);
            testCheckStack.push(53);
            testCheckStack.push(31);
            testCheckStack.push(100);
            testCheckStack.push(55);
            testCheckStack.push(35);
            testCheckStack.push(22);
            testCheckStack.push(72);
            testCheckStack.push(34);
            randtree.preorderTraverse(checkItem);

            testEq((int)findTreeAverage(randtree), 55);
            testEq(findTreeMin(randtree), 22);
            testEq(findTreeMax(randtree), 100);
        } else {
            srand(atoi(argv[2])); 
            BinaryNodeTree<int> randtree = createRandomTree();

            testCheckStack.push(22);
            testCheckStack.push(23);
            testCheckStack.push(93);
            testCheckStack.push(84);
            testCheckStack.push(59);
            testCheckStack.push(51);
            testCheckStack.push(9);
            testCheckStack.push(92);
            testCheckStack.push(10);
            testCheckStack.push(20);
            randtree.preorderTraverse(checkItem);

            testEq((int)findTreeAverage(randtree), 46);
            testEq(findTreeMin(randtree), 9);
            testEq(findTreeMax(randtree), 93);
        }
    }

    if (failures == 0)
        std::cout << "ALL TESTS PASSED" << std::endl;
    else
        std::cout << failures << " TESTS FAILED" << std::endl;

    return 0;
}
