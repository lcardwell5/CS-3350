// File:        BinarySearchTreeIterator.h
// Description: implementation file shell for a binary search tree iterator
// Author:      Luke Cardwell (lcardwe@bgsu.edu)
// Author:      Alex Howey (ahowey@bgsu.edu)
// Course:      CS3350
#include "BinarySearchTreeIterator.h"

template <class ItemType>
BinarySearchTreeIterator<ItemType>::BinarySearchTreeIterator(const BinarySearchTree<ItemType>* someTree, BinaryNode<ItemType>* itemPtr)
{
    containerPtr = someTree;
    currentItemPtr = itemPtr;
    

    //Boolean variable that checks for the end of the traversal
    bool done  = false;
    //Temporary stack to keep track of nodes visited
    LinkedStack<BinaryNode<ItemType>*> tStack;
    //Temporary pointer
    BinaryNode<ItemType>* tPtr = itemPtr;
    
    //While not done...
    while (!done)
    {
        //Advances to the rightmost node of the tree
        if (tPtr != nullptr)
        {
            //Push the pointer to the temporary stack
            tStack.push(tPtr);
            //Advance the temporary pointer to the right child
            tPtr = tPtr->getRightChildPtr();
        }
        else
        {
            //Points the temporary pointer back to the parent node
            if (!tStack.isEmpty())
            {
                //Sets tPtr to the pointer at the top of the stack
                tPtr = tStack.peek();
                //Pops the top pointer from the stack
                tStack.pop();
                //Pushes tPtr to holdingStack
                holdingStack.push(tPtr);
                //Traverses tPtr to the leftmost node
                tPtr = tPtr->getLeftChildPtr();
            }
            else
                done = true;
        }
    }
    
    //Makes currentItemPtr points to the first node in the in-order traversal
    if (!holdingStack.isEmpty())
    {
        currentItemPtr = holdingStack.peek();
        holdingStack.pop();
    } 

} // end constructor

template <class ItemType>
const ItemType BinarySearchTreeIterator<ItemType>::operator*()
{
    //Returns the item of currentItemPtr
    return currentItemPtr->getItem();
} // end operator *

template <class ItemType>
BinarySearchTreeIterator<ItemType> BinarySearchTreeIterator<ItemType>::operator++()
{
    //Advances to the next node in the in-order traversal    
    if (!holdingStack.isEmpty())
    {
        currentItemPtr = holdingStack.peek();
        holdingStack.pop();
    }
    //If the stack is empty, the currentItemPtr is set to nullptr because the last item in the tree has been reached.
    else
        currentItemPtr = nullptr;
   return *this;
} // end operator ++

template <class ItemType>
bool BinarySearchTreeIterator<ItemType>::operator==(const BinarySearchTreeIterator<ItemType>& rightHandSide) const
{
    //Checks for equality
    return ((containerPtr == rightHandSide.containerPtr) && (currentItemPtr == rightHandSide.currentItemPtr));
} // end operator ==

template <class ItemType>
bool BinarySearchTreeIterator<ItemType>::operator!=(const BinarySearchTreeIterator<ItemType>& rightHandSide) const
{
    //Checks for inequality
    return ((containerPtr != rightHandSide.containerPtr) || (currentItemPtr != rightHandSide.currentItemPtr));
} // end operator !=
