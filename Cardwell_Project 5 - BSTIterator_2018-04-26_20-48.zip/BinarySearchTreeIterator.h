// File:        BinarySearchTreeIterator.h
// Description: header file shell for a binary search tree iterator
// Author:      Luke Cardwell (lcardwe@bgsu.edu)
// Author:      Alex Howey (ahowey@bgsu.edu)
// Course:      CS3350
#ifndef _BINARY_SEARCH_TREE_ITERATOR
#define _BINARY_SEARCH_TREE_ITERATOR

#include <iterator>
#include "LinkedStack.cpp"

template <class ItemType>
class BinarySearchTree;

template <class ItemType>
class BinarySearchTreeIterator : public std::iterator<std::input_iterator_tag, int> {
 private:
 //containerPtr points to the tree object
 const BinarySearchTree<ItemType>* containerPtr;
 //currentItemPtr points to the current item in the tree
 BinaryNode<ItemType>* currentItemPtr;
 //stack to hold the nodes in order from the tree
 LinkedStack<BinaryNode<ItemType>*> holdingStack;

 public:
    //Constructor
    BinarySearchTreeIterator(const BinarySearchTree<ItemType>* someTree, BinaryNode<ItemType>* itemPtr);
    
    //Overloaded dereferece operator that returns the dereferenced value
    const ItemType operator*();
    //Overloaded pre-increment ++ operator to advance
    BinarySearchTreeIterator<ItemType> operator ++();
    //Overloaded == operator to check equality
    bool operator == (const BinarySearchTreeIterator<ItemType>& rightHandSide) const;
    //Overloaded != operator to check inequality
    bool operator != (const BinarySearchTreeIterator<ItemType>& rightHandSide) const;
}; // end BinarySearchTreeIterator

#endif
