// File:        project5.cpp
// Description: driver file for Project 5
// Author:      Robert Dyer (rdyer@bgsu.edu)
// Course:      CS3350
#include <iostream>
#include <algorithm>
#include "BinarySearchTree.cpp"


int main(int argc, char **argv) {
    
int arr1[10] = { 33, 29, 13, 39, 47, 9, 15, 30, 10, 17 };
int arr2[50] = { 32, 49, 24, 26, 14, 36, 41, 21, 43, 37, 33, 29, 13, 39, 47, 9, 15, 30, 10, 17, 28, 22, 25, 19, 44, 48, 1, 27, 16, 3, 45, 34, 18, 40, 7, 35, 46, 50, 20, 23, 12, 2, 6, 42, 38, 31, 5, 8, 4, 11 };

BinarySearchTree<int> tree1;
for (int i = 0; i < 10; i++)
  tree1.add(arr1[i]);

BinarySearchTree<int> tree2;
for (int i = 0; i < 50; i++)
  tree2.add(arr2[i]);

std::sort(arr1, arr1 + 10);
std::sort(arr2, arr2 + 50);


BinarySearchTreeIterator<int> iter1 = tree1.begin();
BinarySearchTreeIterator<int> iter2 = tree2.begin();

 for (int i = 0; i < 10; i++) 
{
    if (iter1 == tree1.end())
        std::cout << "iter 1 = end" << std::endl;
    if (iter2 == tree2.end())
        std::cout << "iter 2 = end" << std::endl;
    if (*iter1 != arr1[i])
        std::cout << "iter 1 !=" << std::endl;
    if (*iter2 != arr2[i])
        std::cout << "iter 2 !=" << std::endl;
  ++iter1;
  ++iter2;
}
std::cout << "Done" << std::endl; 

 for (int i = 10; i < 50; i++) 
{
    if (iter1 == tree1.end())
        std::cout << "iter 1 = end" << std::endl;
    if (iter2 == tree2.end())
        std::cout << "iter 2 = end" << std::endl;
    if (*iter2 != arr2[i])
        std::cout << "iter 2 !=" << std::endl;
  ++iter2;
} 
std::cout << "Done" << std::endl; 
}
