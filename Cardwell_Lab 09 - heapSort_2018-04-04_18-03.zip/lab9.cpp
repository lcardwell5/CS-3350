// File:        lab9.cpp
// Description: driver file for lab 9
// Author:      Luke Cardwell (lcardwe@bgsu.edu)
// Course:      CS3350, Fall 2017
#include <algorithm>
#include <iostream>

void heapCreate(int* anArray, int n);

void heapRebuild(int index, int* anArray, int n) {
    int largerChildIndex;
    int rightChildIndex;
    int tVal;
    
    if ((2 * index + 1) < n)
    {
        largerChildIndex = 2 * index + 1;
        
        if ((2 * index + 2) < n)
        {
            rightChildIndex = largerChildIndex + 1;
            if (anArray[rightChildIndex] > anArray[largerChildIndex])
                largerChildIndex = rightChildIndex;
        }
        
        if (anArray[index] < anArray[largerChildIndex])
        {
            tVal = anArray[index];
            anArray[index] = anArray[largerChildIndex];
            anArray[largerChildIndex] = tVal;
            
            heapRebuild(largerChildIndex, anArray, n);
        }
    }
}

void heapSort(int* anArray, int n) {
    int tVal;
    int heapSize;
    
    heapCreate(anArray, n);
    
    tVal = anArray[0];
    anArray[0] = anArray[n-1];
    anArray[n-1] = tVal;
    
    heapSize = n-1;
    
    while(heapSize > 1)
    {
        heapRebuild(0, anArray, heapSize);
        
        tVal = anArray[0];
        anArray[0] = anArray[heapSize - 1];
        anArray[heapSize - 1] = tVal;
        
        heapSize --;
    }
    
    
}

//////////////////////////////
// DO NOT MODIFY BELOW HERE //
//////////////////////////////

void heapCreate(int* anArray, int n) {
    for (int i = n / 2; i >= 0; i--)
        heapRebuild(i, anArray, n);
}

int failures = 0;

void testEq(int result, int expected) {
    if (result != expected) {
        std::cout << "test FAILED: expected(" << expected << ") but result(" << result << ")" << std::endl;
        failures++;
    }
}

void testHeap(int *anArray, int n) {
    int *sorted = new int[n];
    for (int i = 0; i < n; i++)
        sorted[i] = anArray[i];

    std::sort(sorted, sorted + n);
    heapSort(anArray, n);

    for (int i = 0; i < n; i++)
        testEq(anArray[i], sorted[i]);
}

int main(int argc, char **argv)
{
    int heap1[] = { 1 };
    testHeap(heap1, sizeof(heap1) / sizeof(int));

    int heap2[] = { 4, 3, 2, 1 };
    testHeap(heap2, sizeof(heap2) / sizeof(int));

    int heap3[] = { 5, 4, 3, 2, 1 };
    testHeap(heap3, sizeof(heap3) / sizeof(int));

    int heap4[] = { 1, 1, 1, 1 };
    testHeap(heap4, sizeof(heap4) / sizeof(int));

    int heap5[] = { 57, 28, 22, 10, 41, 51, 56, 100, 19, 79, 97, 32, 95, 16, 18,
        91, 73, 5, 44, 54, 4, 81, 75, 60, 25, 72, 85, 97, 78, 60, 72, 50, 30, 97,
        74, 17, 21, 52, 16, 80, 85, 63, 32, 93, 77, 18, 25, 19, 80, 50, 16, 14, 28,
        16, 55, 25, 2, 19, 5, 10, 81, 3, 41, 34, 66, 75, 59, 65, 39, 33, 1, 21, 2,
        72, 15, 50, 23, 65, 64, 10, 43, 41, 59, 76, 29, 50, 22, 91, 31, 50, 1, 91,
        79, 85, 78, 90, 81, 24, 46, 29 };
    testHeap(heap5, sizeof(heap5) / sizeof(int));

    if (failures == 0)
        std::cout << "ALL TESTS PASSED" << std::endl;
    else
        std::cout << failures << " TESTS FAILED" << std::endl;

    return 0;
}
