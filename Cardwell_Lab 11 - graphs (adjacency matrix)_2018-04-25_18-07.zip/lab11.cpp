// File:        lab11.cpp
// Description: driver file for lab 11
// Author:      Robert Dyer (rdyer@bgsu.edu)
// Course:      CS3350
#include <iostream>
#include <algorithm>
#include "directedgraph.cpp"

int failures = 0;

void testEq(int result, int expected) {
    if (result != expected) {
        std::cout << "test FAILED: expected(" << expected << ") but result(" << result << ")" << std::endl;
        failures++;
    }
}

int main(int argc, char **argv)
{
    DirectedGraph g(10);

    g.addEdge(5, 2);
    g.addEdge(5, 3);
    g.addEdge(5, 5);

    testEq(g.hasEdge(2, 5), false);
    testEq(g.hasEdge(3, 5), false);
    testEq(g.hasEdge(5, 2), true);
    testEq(g.hasEdge(5, 3), true);
    testEq(g.hasEdge(5, 5), true);

    std::vector<int> v = g.adjacent(5);
    testEq(v.size(), 3);

    std::sort(v.begin(), v.end());
    testEq(v[0], 2);
    testEq(v[1], 3);
    testEq(v[2], 5);

    if (failures == 0)
        std::cout << "ALL TESTS PASSED" << std::endl;
    else
        std::cout << failures << " TESTS FAILED" << std::endl;

    return 0;
}
