// File:        graph.cpp
// Description: implementation file for a directed graph class
// Author:      TODO (TODO@bgsu.edu)
// Course:      CS3350
#include "directedgraph.h"

DirectedGraph::DirectedGraph(int size)
{
    this->size = size;
    adjMatrix = new int*[size];
    for(int i = 0; i < size; i++)
    {
        adjMatrix[i] = new int [size];
    }
}

DirectedGraph::~DirectedGraph()
{
    for (int i = 0; i < size; i++)
    {
        delete adjMatrix[i];
    }
    
    delete adjMatrix;
}

void DirectedGraph::addEdge(int src, int dst)
{
    adjMatrix[src][dst] = 1;
}

bool DirectedGraph::hasEdge(int src, int dst)
{
    if(adjMatrix[src][dst] == 1)
        return true;
    else
        return false;
}

std::vector<int> DirectedGraph::adjacent(int src)
{
    std::vector<int> v;
    
    for(int i = 0; i < size; i++)
    {
        if(adjMatrix[src][i] == 1)
            v.push_back(i);
    }
        
    return v;
}
