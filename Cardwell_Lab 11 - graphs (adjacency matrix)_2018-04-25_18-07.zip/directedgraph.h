// File:        graph.cpp
// Description: header file for a directed graph class
// Author:      TODO (TODO@bgsu.edu)
// Course:      CS3350
#ifndef GRAPH_H
#define GRAPH_H

#include <vector>

class DirectedGraph {
private:
    int size;
    int** adjMatrix;

public:
    DirectedGraph(int);
    ~DirectedGraph();

    void addEdge(int, int);
    bool hasEdge(int, int);

    std::vector<int> adjacent(int);
};

#endif
